#!/data/data/com.termux/files/usr/bin/bash
cd $HOME
pkg install figlet
figlet INSTALLING
pkg install wget
wget https://raw.githubusercontent.com/Hax4us/Apkmod/master/setup.sh
sh setup.sh
cd djbinder
rm -rf install.sh
figlet INSTALED

